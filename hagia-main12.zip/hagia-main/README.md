# HAGIA

What is Hagia?

Hagia is a 2D game engine and toolset for Python.

Hagia has two tools:

1. Sprite Editor
2. Map Editor

Unfortunately, Hagia does not provide a way of making music with it's toolset.
To do so, you will have to use any means you choose.
Just make sure all the music and audio are in the correct formats (.ogg for music, .wav for sound effects).

More documentation is on the way, so eventually Hagia will be usable.
Er, well, it already is, though documentation sure does go a long way.

# DONATIONS

If you are feeling generous, feel free to donate cryptocurrency to the addresses below.

```
XMR (Monero) - 8ArbtKgt22ST4D7SrvMgT2BZcTdEDSP3bd5Xc73qvepXYJD4a8v1BYtcaw9ntNtqGrVRzGLFdJGgVgGFL7h32Zy7UPry7pL
```

Currently, only Monero (XMR) is accepted.
If you would like to donate, but in another currency, please put such in Issues for the acceptance of said currency to be considered.

## More coming soon . . .
