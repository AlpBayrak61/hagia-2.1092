debug = False
version = (0,1,0)
engine_data_dir = './Engine_Data/'
default_font = engine_data_dir + 'mono_upper.ttf'